Team:
Shruti Saravanan
Ganavi Jayaram

Assignment 4: Stocks (Part 1)

	1. Controller: The controller sets up a command line interface for the user to interact with the program. It puts up a menu for the user to choose an option and surf through creating and viewing portfolios.

	2. Model: There are two models Portfolio and Stock. Portfolio provides all the methods necessary to execute the menu. Users can add stocks to a portfolio only when the portfolio is created in menu option 1. Stock provides methods to get the data for the stocks from the Alpha Vantage API.

    3. View: Nothing implemented yet for this assignment.
